class Scheduler:
    def detect_conflict(self):
        return ""
